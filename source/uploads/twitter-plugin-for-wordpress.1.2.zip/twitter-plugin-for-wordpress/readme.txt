=== Twitter Plugin for Wordpress 1.0 ===
Tags: twitter, twitter feed, twitter sidebar, sidebar, social sidebar
Requires at least: 2.9.2 or higher
Tested up to: 3.0.1
Stable tag: 1.2
Donate link: http://www.dallasprowebdesigners.com/

Twitter Plugin for Wordpress to show your latest tweets on you wordpress blog.

== Description ==

Show your latest twitter posts with this easy to use twitter sidebar plugin widget for Wordpress. Easy to setup and easy to use. You can be letting the world see your lates tweets in no time by downloading this easy to use Wordpress twitter widget. You can see this widget in action at our<a href="http://www.dallasprowebdesigners.com">Web Designers</a> plugin page.

**Features**

    * Very easy to use
    * Will install in seconds
    * Simple to install
    * Lots of customize options
    * Uses your existing wordpress files for css, and styles
    * Can choose to detect urls, no follows and choose the number or tweets to display
	
A complete list of features and other info can be found at <a href="http://www.dallasprowebdesigners.com/" title="Website Design Company"> Web Design Company</a>. Go here to see a list of <a href="http://www.dallasprowebdesigners.com/dallas-web-design.html" title="Dallas Web Designers">Dallas Web Design</a> companies using this plugin.
	
	
**Usage**

Once you have installed the twitter widget you will need to click on appearence then click on widgets and you will find the twitter widget there. You can then simply drag the twitter widget over and drop it into the location you want it to show on your website. Then click the little arrow and the twitter widget will have a drop down menu which will allow you to change and add options you wisht to display.

* See the <a href="http://www.dallasprowebdesigners.com">Web Design Company</a> that developed this for further information. 
Developer documentation is also available for those who need instructions on how to make modifications.

We specialize in <a href="http://www.dallasprowebdesigners.com/e-commerce-web-design.html" title="ecomerce web designers">Ecommerce Web Design</a> and make no warranties against this plugin. If you need help installing please contact us using our support like found on our website. As with installing any new plugins on your website we encourage you to create a backup copy of your site. You are free to use and distribute this plugin as you want.

== Demo ==
View this simple to use sidebar widget in action at <a href="http://www.dallasprowebdesigners.com/blog/">WP Sidebar Twitter Widget</a>


== Installation ==

Either use your install option in the administration section of your WordPress blog or unzip
the files and drag and drop the entire folder wp-tweeter-sidebar into your plugins folder using your favorite ftp software. 
If you need help installing this please visit us online at <a href="http://wwww.dallasprowebdesigners.com/">Support</a> and use 
contact us for support or help.

== Frequently Asked Questions == 

=Can i control how many tweets will display on my site?=

*Yes you can choose to display as many of your latest tweets as you like.


=Will the widget look different than the rest of my site or will I have to change some css or backgrounds in the code to make it look noraml on my site?=

*No the twitter widget is designed to use your existing css files and design files so that the widget will look like the rest of your site such as a menu showing the same title text color and size, background color etc.


== Credits ==

[David Alford](http://www.dallasprowebdesigners.com/) - 
The plugin was built utilizing Pownce for Wordpress widget with major modifications and features added.
In was made avaialbe by <a href="http://www.dallasprowebdesigners.com/" title="Website Design Company">
Web Design Company</a> Pro Web Design Studios and cheif developer David Alford.

== Contact ==

To contact the <a href="http://www.dallasprowebdesigners.com/">Web Designer</a> of this widget
you can do so by visiting <a href="http://www.dallasprowebdesigners.com/">Pro Web Designers</a>.

== Changelog ==

1.2 version release with some updates. Added the ability to make changes to the css file in order for the plugin user to adjust background colors as well as other css styles to make the plugin look consistant with the rest of their website


== License ==

WP Twitter Sidebar Widget is released under the GNU General Public License V3.
For more information please read<a href="http://www.gnu.org/copyleft/gpl.html">http://www.gnu.org/copyleft/gpl.html</a>
